# Business Channel Data Load Wizard

A complete, interactive CSV data import wizard web prototype built with **React + TypeScript + Tailwind CSS**. Pure frontend mock — no backend required.

## Features

- **4-step wizard** with a shared step indicator:
  1. Business Channel - Data Load Source
  2. Business Channel - Data / Table Mapping
  3. Business Channel - Data Validation
  4. Business Channel - Data Load Results
- Step indicator states: completed (green check), current (blue dot), pending (gray dot)
- Step 1: file upload (`.csv` only), separator & format config, globalization settings
- Step 2: target/source column mapping table with sample data rows
- Step 3: validation table with INSERT action badges, error row highlighting (red), pagination
- Step 4: load results summary with inserted/updated/failed/to-be-reviewed counts
- Full navigation: Next / Previous / Load Data / Finish / Cancel
- Enterprise admin style: white background, full-border tables, clean minimal design

## Quick Start

### Option A: Vite Dev Server (Recommended)

```bash
npm install
npm run dev
```

Then open http://localhost:5173 in your browser.

### Option B: Single-File HTML Preview

Open `preview.html` directly in any modern browser — no build step needed. Uses CDN-loaded React, Babel, and Tailwind.

### Build for Production

```bash
npm run build
npm run preview
```

## Project Structure

```
business-channel-data-load-wizard/
├── index.html                  # Vite entry HTML
├── preview.html                # Single-file CDN preview (open directly)
├── package.json
├── tsconfig.json
├── tsconfig.node.json
├── vite.config.ts
├── tailwind.config.js
├── postcss.config.js
├── README.md
└── src/
    ├── main.tsx                # React entry point
    ├── App.tsx                 # Root component
    ├── index.css               # Tailwind + enterprise styles
    ├── types/
    │   └── index.ts            # TypeScript type definitions
    └── components/
        ├── StepIndicator.tsx   # Shared 4-step progress bar
        ├── BusinessChannelDataLoadWizard.tsx  # Main wizard (state + routing)
        └── steps/
            ├── DataLoadSource.tsx    # Step 1
            ├── DataTableMapping.tsx  # Step 2
            ├── DataValidation.tsx    # Step 3
            └── DataLoadResults.tsx   # Step 4
```

## Interaction Logic

| Step | Action | Result |
|------|--------|--------|
| 1 | Next (file selected) | → Step 2 |
| 1 | Next (no file) | Button disabled |
| 1 | Cancel | Reset to Step 1 |
| 2 | Previous | → Step 1 |
| 2 | Next | → Step 3 |
| 2 | Cancel | Reset to Step 1 |
| 3 | Previous | → Step 2 |
| 3 | Load Data (no errors) | → Step 4 |
| 3 | Load Data (has errors) | Button disabled |
| 3 | Cancel | Reset to Step 1 |
| 4 | Finish | Reset to Step 1 |
| 4 | Cancel | Reset to Step 1 |

## Error Row Demo

To see the red error highlighting and disabled "Load Data" button in action, edit `src/components/BusinessChannelDataLoadWizard.tsx` and set `hasError: true` on any row in `defaultValidationRows`, e.g.:

```ts
{
  sequence: 1,
  action: 'INSERT',
  idBusinessChannel: '544',
  // ...
  hasError: true,
  errorMessage: 'ID_BUSINESS_CHANNEL must be a valid number',
}
```

## Tech Stack

- React 18
- TypeScript 5
- Tailwind CSS 3
- Vite 5
