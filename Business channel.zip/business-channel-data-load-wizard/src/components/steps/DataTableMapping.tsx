import React from 'react';
import type { FieldMapping } from '../../types';

interface DataTableMappingProps {
  fieldMappings: FieldMapping[];
  onCancel: () => void;
  onPrevious: () => void;
  onNext: () => void;
}

/**
 * Step2: Business Channel Data / Table Mapping
 * 表格三层结构：Target Column / Source Column / 样例数据行
 */
const DataTableMapping: React.FC<DataTableMappingProps> = ({
  fieldMappings,
  onCancel,
  onPrevious,
  onNext,
}) => {
  // 样例数据
  const sampleRows = [
    {
      idBusinessChannel: '544',
      plReportingLine: 'Commission income',
      counterparty: 'ICO',
      businessChannel: 'MP',
      derivedChannel: 'MEM',
    },
    {
      idBusinessChannel: '545',
      plReportingLine: 'Commission income',
      counterparty: 'ICO',
      businessChannel: 'XA',
      derivedChannel: 'DSA',
    },
  ];

  const sampleValues = (row: typeof sampleRows[number]) => [
    row.idBusinessChannel,
    row.plReportingLine,
    row.counterparty,
    row.businessChannel,
    row.derivedChannel,
  ];

  return (
    <div className="flex flex-col h-full">
      {/* 顶部操作栏 */}
      <div className="flex items-center justify-between px-8 py-4 border-b border-enterprise-border bg-white">
        <div className="flex items-center gap-3">
          <button className="btn btn-secondary" onClick={onCancel}>
            Cancel
          </button>
          <button className="btn btn-secondary" onClick={onPrevious}>
            Previous
          </button>
        </div>
        <button className="btn btn-primary" onClick={onNext}>
          Next
        </button>
      </div>

      {/* 提示文字 */}
      <div className="px-8 py-3 bg-enterprise-bg border-b border-enterprise-border">
        <p className="text-sm text-gray-600 italic">
          Screen Displays Column Mapping for Reference, Full Row Count from Source File is
          Under "Data Validation"
        </p>
      </div>

      {/* 表格内容区 */}
      <div className="flex-1 overflow-auto px-8 py-6 bg-enterprise-bg">
        <div className="bg-white border border-enterprise-border rounded overflow-hidden">
          <div className="overflow-x-auto">
            <table className="enterprise-table min-w-full">
              <thead>
                {/* Target Column 行 */}
                <tr>
                  <th className="w-40 bg-gray-100 font-semibold text-gray-700 sticky left-0 z-10">
                    Target Column
                  </th>
                  {fieldMappings.map((mapping, idx) => (
                    <th key={idx} className="text-left font-semibold text-gray-800 whitespace-nowrap">
                      {mapping.target.name}
                      <span className="ml-1 text-xs font-normal text-gray-500">
                        - {mapping.target.type}
                      </span>
                      {mapping.target.required && (
                        <span className="ml-1 text-enterprise-error">*</span>
                      )}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {/* Source Column 行 */}
                <tr>
                  <td className="bg-gray-50 font-medium text-gray-700 sticky left-0 z-10">
                    Source Column
                  </td>
                  {fieldMappings.map((mapping, idx) => (
                    <td key={idx} className="text-gray-700 whitespace-nowrap">
                      {mapping.source}
                    </td>
                  ))}
                </tr>
                {/* 样例数据 Row1 */}
                <tr>
                  <td className="bg-gray-50 font-medium text-gray-700 sticky left-0 z-10">
                    Row 1
                  </td>
                  {sampleValues(sampleRows[0]).map((val, idx) => (
                    <td key={idx} className="text-gray-700 whitespace-nowrap">
                      {val}
                    </td>
                  ))}
                </tr>
                {/* 样例数据 Row2 */}
                <tr>
                  <td className="bg-gray-50 font-medium text-gray-700 sticky left-0 z-10">
                    Row 2
                  </td>
                  {sampleValues(sampleRows[1]).map((val, idx) => (
                    <td key={idx} className="text-gray-700 whitespace-nowrap">
                      {val}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* 说明文字 */}
        <div className="mt-4 text-xs text-gray-500">
          <p>* Indicates required field. Column mapping is auto-detected based on source file headers.</p>
        </div>
      </div>
    </div>
  );
};

export default DataTableMapping;
