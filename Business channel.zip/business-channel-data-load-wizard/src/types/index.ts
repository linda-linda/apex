// 全局类型定义

/** 文件信息 */
export interface FileInfo {
  name: string;
  size: number;
  type: string;
}

/** 分隔符与文件格式配置 */
export interface FileFormatConfig {
  separator: string;
  enclosedBy: string;
  firstRowHasColumnNames: boolean;
  useApplicationDateFormat: boolean;
  fileCharacterSet: string;
}

/** 全球化配置 */
export interface GlobalizationConfig {
  currencySymbol: string;
  groupSeparator: string;
  decimalCharacter: string;
}

/** 目标列定义 */
export interface TargetColumn {
  name: string;
  type: string;
  required?: boolean;
}

/** 字段映射 */
export interface FieldMapping {
  target: TargetColumn;
  source: string;
}

/** 校验行数据 */
export interface ValidationRow {
  sequence: number;
  action: string;
  idBusinessChannel: string;
  plReportingLine: string;
  counterparty: string;
  businessChannel: string;
  derivedChannel: string;
  hasError?: boolean;
  errorMessage?: string;
}

/** 加载结果统计 */
export interface LoadResults {
  insertedRows: number;
  updatedRows: number;
  failedRows: number;
  toBeReviewedRows: number;
}

/** 向导全局状态 */
export interface WizardState {
  currentStep: number;
  fileInfo: FileInfo | null;
  fileFormat: FileFormatConfig;
  globalization: GlobalizationConfig;
  fieldMappings: FieldMapping[];
  validationRows: ValidationRow[];
  loadResults: LoadResults;
}

/** 步骤定义 */
export interface StepDefinition {
  id: number;
  label: string;
}
