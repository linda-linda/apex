/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'enterprise-blue': '#1a73e8',
        'enterprise-green': '#34a853',
        'enterprise-gray': '#9aa0a6',
        'enterprise-border': '#dadce0',
        'enterprise-bg': '#f8f9fa',
        'enterprise-error': '#d93025',
      }
    },
  },
  plugins: [],
}
