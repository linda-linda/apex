// 全局类型定义

/** 文件信息 */
export interface FileInfo {
  name: string;
  size: number;
  type: string;
}

/** 分隔符与文件格式配置 */
export interface FileFormatConfig {
  separator: string;
  enclosedBy: string;
  firstRowHasColumnNames: boolean;
  useApplicationDateFormat: boolean;
  fileCharacterSet: string;
}

/** 全球化配置 */
export interface GlobalizationConfig {
  currencySymbol: string;
  groupSeparator: string;
  decimalCharacter: string;
}

/** 目标列定义 */
export interface TargetColumn {
  name: string;
  type: string;
  required?: boolean;
}

/** 源字段选项（Step2 Source Column 下拉候选，写死的 8 项） */
export interface SourceFieldOption {
  /** 唯一 key，如 'ID_BUSINESS_CHANNEL'；DO_NOT_LOAD 为特殊项 */
  key: string;
  /** 展示名 */
  label: string;
  /** 数据类型，如 varchar2(100)、number */
  type: string;
  /** 是否必填（ID_BUSINESS_CHANNEL 带 *） */
  required?: boolean;
  /** 是否为 "Do Not Load" 特殊项 */
  doNotLoad?: boolean;
  /** 样例数据 Row1 */
  sampleRow1?: string;
  /** 样例数据 Row2 */
  sampleRow2?: string;
}

/** 字段映射：target 为数据库目标字段，source 为已选中的源字段 key（'' = 未映射，DO_NOT_LOAD = 不加载） */
export interface FieldMapping {
  target: TargetColumn;
  source: string;
}

/** 校验行数据 */
export interface ValidationRow {
  sequence: number;
  action: string;
  idBusinessChannel: string;
  plReportingLine: string;
  counterparty: string;
  businessChannel: string;
  derivedChannel: string;
  hasError?: boolean;
  errorMessage?: string;
}

/** 加载结果统计 */
export interface LoadResults {
  insertedRows: number;
  updatedRows: number;
  failedRows: number;
  toBeReviewedRows: number;
}

/** 向导全局状态 */
export interface WizardState {
  currentStep: number;
  fileInfo: FileInfo | null;
  fileFormat: FileFormatConfig;
  globalization: GlobalizationConfig;
  fieldMappings: FieldMapping[];
  validationRows: ValidationRow[];
  loadResults: LoadResults;
}

/** 步骤定义 */
export interface StepDefinition {
  id: number;
  label: string;
}
