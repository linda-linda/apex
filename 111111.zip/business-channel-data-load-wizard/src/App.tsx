import BusinessChannelDataLoadWizard from './components/BusinessChannelDataLoadWizard';

function App() {
  return <BusinessChannelDataLoadWizard />;
}

export default App;
