import React from 'react';
import type { LoadResults } from '../../types';

interface DataLoadResultsProps {
  loadResults: LoadResults;
  onCancel: () => void;
  onFinish: () => void;
}

/**
 * Step4: Business Channel Data Load Results
 * 展示数据加载结果统计
 */
const DataLoadResults: React.FC<DataLoadResultsProps> = ({
  loadResults,
  onCancel,
  onFinish,
}) => {
  const resultItems = [
    {
      label: 'Inserted Row(s)',
      value: loadResults.insertedRows,
      color: 'text-enterprise-green',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
      ),
    },
    {
      label: 'Updated Row(s)',
      value: loadResults.updatedRows,
      color: 'text-enterprise-blue',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
        </svg>
      ),
    },
    {
      label: 'Failed Row(s)',
      value: loadResults.failedRows,
      color: 'text-enterprise-error',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-200',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      ),
    },
    {
      label: 'To be Reviewed Row(s)',
      value: loadResults.toBeReviewedRows,
      color: 'text-amber-600',
      bgColor: 'bg-amber-50',
      borderColor: 'border-amber-200',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
        </svg>
      ),
    },
  ];

  const totalProcessed =
    loadResults.insertedRows +
    loadResults.updatedRows +
    loadResults.failedRows +
    loadResults.toBeReviewedRows;

  const isSuccess = loadResults.failedRows === 0;

  return (
    <div className="flex flex-col h-full">
      {/* 顶部操作栏 */}
      <div className="flex items-center justify-between px-8 py-4 border-b border-enterprise-border bg-white">
        <button className="btn btn-secondary" onClick={onCancel}>
          Cancel
        </button>
        <button className="btn btn-primary" onClick={onFinish}>
          Finish
        </button>
      </div>

      {/* 页面标题 */}
      <div className="px-8 py-4 bg-white border-b border-enterprise-border">
        <h1 className="text-lg font-semibold text-gray-800">
          Business Channel Data Load Results
        </h1>
      </div>

      {/* 结果内容区 */}
      <div className="flex-1 overflow-auto px-8 py-8 bg-enterprise-bg">
        <div className="max-w-2xl mx-auto">
          {/* 状态横幅 */}
          <div
            className={`mb-6 p-4 rounded border ${
              isSuccess
                ? 'bg-green-50 border-green-200'
                : 'bg-red-50 border-red-200'
            }`}
          >
            <div className="flex items-center">
              {isSuccess ? (
                <svg className="w-8 h-8 text-enterprise-green mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              ) : (
                <svg className="w-8 h-8 text-enterprise-error mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              )}
              <div>
                <p className={`text-sm font-semibold ${isSuccess ? 'text-enterprise-green' : 'text-enterprise-error'}`}>
                  {isSuccess ? 'Data Load Completed Successfully' : 'Data Load Completed with Errors'}
                </p>
                <p className="text-xs text-gray-600 mt-0.5">
                  Total {totalProcessed} row(s) processed.
                </p>
              </div>
            </div>
          </div>

          {/* 统计卡片网格 */}
          <div className="grid grid-cols-2 gap-4">
            {resultItems.map((item) => (
              <div
                key={item.label}
                className={`p-4 rounded border ${item.bgColor} ${item.borderColor}`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">{item.label}</span>
                  <span className={item.color}>{item.icon}</span>
                </div>
                <p className={`text-3xl font-bold mt-2 ${item.color}`}>
                  {item.value}
                </p>
              </div>
            ))}
          </div>

          {/* 纯文本统计（按需求原文展示） */}
          <div className="mt-6 p-4 bg-white border border-enterprise-border rounded">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">Summary</h3>
            <div className="space-y-2 text-sm text-gray-700 font-mono">
              <p>Inserted Row(s): {loadResults.insertedRows}</p>
              <p>Updated Row(s): {loadResults.updatedRows}</p>
              <p>Failed Row(s): {loadResults.failedRows}</p>
              <p>To be Reviewed Row(s): {loadResults.toBeReviewedRows}</p>
            </div>
          </div>

          {/* 操作提示 */}
          <div className="mt-6 text-center">
            <p className="text-xs text-gray-500">
              Click <span className="font-semibold text-gray-700">Finish</span> to return to the start and load another file.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataLoadResults;
