import React from 'react';
import type { ValidationRow } from '../../types';

interface DataValidationProps {
  validationRows: ValidationRow[];
  onCancel: () => void;
  onPrevious: () => void;
  onLoadData: () => void;
}

/**
 * Step3: Business Channel Data Validation
 * 展示校验后的数据行，有错误行时 Load Data 按钮禁用
 */
const DataValidation: React.FC<DataValidationProps> = ({
  validationRows,
  onCancel,
  onPrevious,
  onLoadData,
}) => {
  // 检查是否存在错误行
  const hasErrorRows = validationRows.some((row) => row.hasError);
  const totalRows = validationRows.length;

  return (
    <div className="flex flex-col h-full">
      {/* 顶部操作栏 */}
      <div className="flex items-center justify-between px-8 py-4 border-b border-enterprise-border bg-white">
        <div className="flex items-center gap-3">
          <button className="btn btn-secondary" onClick={onCancel}>
            Cancel
          </button>
          <button className="btn btn-secondary" onClick={onPrevious}>
            Previous
          </button>
        </div>
        <button
          className="btn btn-primary"
          onClick={onLoadData}
          disabled={hasErrorRows}
          title={hasErrorRows ? 'Cannot load data with error rows' : 'Load validated data into target table'}
        >
          Load Data
        </button>
      </div>

      {/* 页面标题 */}
      <div className="px-8 py-4 bg-white border-b border-enterprise-border">
        <h1 className="text-lg font-semibold text-gray-800">
          Business Channel Data Validation
        </h1>
      </div>

      {/* 表格内容区 */}
      <div className="flex-1 overflow-auto px-8 py-6 bg-enterprise-bg">
        <div className="bg-white border border-enterprise-border rounded overflow-hidden">
          <div className="overflow-x-auto">
            <table className="enterprise-table min-w-full">
              <thead>
                <tr>
                  <th className="w-20 text-center">Sequence</th>
                  <th className="w-24 text-center">Action</th>
                  <th>ID_BUSINESS_CHANNEL</th>
                  <th>PL_REPORTING_LINE</th>
                  <th>COUNTERPARTY</th>
                  <th>BUSINESS_CHANNEL</th>
                  <th>DERIVED_CHANNEL</th>
                </tr>
              </thead>
              <tbody>
                {validationRows.map((row) => (
                  <tr
                    key={row.sequence}
                    className={row.hasError ? 'error-row' : ''}
                    title={row.hasError ? row.errorMessage : undefined}
                  >
                    <td className="text-center text-gray-700">{row.sequence}</td>
                    <td className="text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-xs font-semibold ${
                          row.action === 'INSERT'
                            ? 'bg-green-100 text-green-700'
                            : row.action === 'UPDATE'
                            ? 'bg-blue-100 text-blue-700'
                            : 'bg-gray-100 text-gray-700'
                        }`}
                      >
                        {row.action}
                      </span>
                    </td>
                    <td className="text-gray-700 whitespace-nowrap">{row.idBusinessChannel}</td>
                    <td className="text-gray-700 whitespace-nowrap">{row.plReportingLine}</td>
                    <td className="text-gray-700 whitespace-nowrap">{row.counterparty}</td>
                    <td className="text-gray-700 whitespace-nowrap">{row.businessChannel}</td>
                    <td className="text-gray-700 whitespace-nowrap">{row.derivedChannel}</td>
                  </tr>
                ))}
                {validationRows.length === 0 && (
                  <tr>
                    <td colSpan={7} className="text-center text-gray-400 py-8">
                      No data rows to validate.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* 分页信息 */}
          <div className="flex items-center justify-between px-4 py-2 bg-gray-50 border-t border-enterprise-border">
            <div className="text-xs text-gray-500">
              {hasErrorRows ? (
                <span className="text-enterprise-error font-medium">
                  ⚠ {validationRows.filter((r) => r.hasError).length} row(s) with errors — fix before loading
                </span>
              ) : (
                <span className="text-enterprise-green font-medium">
                  ✓ All {totalRows} row(s) passed validation
                </span>
              )}
            </div>
            <div className="text-xs text-gray-500">
              {totalRows > 0 ? `1-${totalRows}` : '0-0'} of {totalRows}
            </div>
          </div>
        </div>

        {/* 错误行演示说明（开发注释） */}
        {/*
          ============================================================
          错误行红色高亮演示：
          要开启错误行演示，在 BusinessChannelDataLoadWizard.tsx 的
          initialValidationRows 中，将某行的 hasError 设为 true，例如：
          {
            sequence: 1,
            action: 'INSERT',
            idBusinessChannel: '544',
            ...
            hasError: true,
            errorMessage: 'ID_BUSINESS_CHANNEL must be a valid number',
          }
          此时该行会以红色背景高亮，且 Load Data 按钮自动禁用。
          ============================================================
        */}
        <div className="mt-4 text-xs text-gray-400">
          <p>Rows with validation errors are highlighted in red and block data loading.</p>
        </div>
      </div>
    </div>
  );
};

export default DataValidation;
