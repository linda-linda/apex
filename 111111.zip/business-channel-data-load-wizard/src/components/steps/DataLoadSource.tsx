import React, { useRef } from 'react';
import type { FileInfo, FileFormatConfig, GlobalizationConfig } from '../../types';

interface DataLoadSourceProps {
  fileInfo: FileInfo | null;
  fileFormat: FileFormatConfig;
  globalization: GlobalizationConfig;
  onFileChange: (file: FileInfo | null) => void;
  onFileFormatChange: (config: FileFormatConfig) => void;
  onGlobalizationChange: (config: GlobalizationConfig) => void;
  onCancel: () => void;
  onNext: () => void;
}

/**
 * Step1: Business Channel Data Load Source
 */
const DataLoadSource: React.FC<DataLoadSourceProps> = ({
  fileInfo,
  fileFormat,
  globalization,
  onFileChange,
  onFileFormatChange,
  onGlobalizationChange,
  onCancel,
  onNext,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileChange({
        name: file.name,
        size: file.size,
        type: file.type,
      });
    } else {
      onFileChange(null);
    }
  };

  const handleFormatFieldChange = <K extends keyof FileFormatConfig>(
    key: K,
    value: FileFormatConfig[K]
  ) => {
    onFileFormatChange({ ...fileFormat, [key]: value });
  };

  const handleGlobalFieldChange = <K extends keyof GlobalizationConfig>(
    key: K,
    value: GlobalizationConfig[K]
  ) => {
    onGlobalizationChange({ ...globalization, [key]: value });
  };

  const canProceed = fileInfo !== null;

  return (
    <div className="flex flex-col h-full">
      {/* 顶部操作栏 */}
      <div className="flex items-center justify-between px-8 py-4 border-b border-enterprise-border bg-white">
        <button className="btn btn-secondary" onClick={onCancel}>
          Cancel
        </button>
        <button
          className="btn btn-primary"
          onClick={onNext}
          disabled={!canProceed}
        >
          Next
        </button>
      </div>

      {/* 页面标题 */}
      <div className="px-8 py-4 bg-white border-b border-enterprise-border">
        <h1 className="text-lg font-semibold text-gray-800">
          Business Channel Data Load Source
        </h1>
      </div>

      {/* 表单内容区 */}
      <div className="flex-1 overflow-auto px-8 py-6 bg-enterprise-bg">
        <div className="max-w-3xl mx-auto bg-white border border-enterprise-border rounded p-6">
          {/* 文件格式配置 */}
          <div className="space-y-4">
            {/* File Name */}
            <div className="flex items-center">
              <label className="w-56 text-sm text-gray-700 flex-shrink-0">
                File Name <span className="text-enterprise-error">*</span>
              </label>
              <div className="flex-1 flex items-center">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv"
                  onChange={handleFileSelect}
                  className="text-sm text-gray-600 file:mr-3 file:py-1 file:px-3 file:rounded file:border file:border-enterprise-border file:bg-white file:text-sm file:text-gray-700 file:cursor-pointer hover:file:bg-gray-50"
                />
                {fileInfo && (
                  <span className="ml-3 text-xs text-gray-500">
                    {fileInfo.name} ({(fileInfo.size / 1024).toFixed(1)} KB)
                  </span>
                )}
              </div>
              <span className="help-icon" title="Select a CSV file to load">?</span>
            </div>

            {/* Separator */}
            <div className="flex items-center">
              <label className="w-56 text-sm text-gray-700 flex-shrink-0">
                Separator <span className="text-enterprise-error">*</span>
              </label>
              <div className="flex-1">
                <input
                  type="text"
                  className="form-input w-32"
                  value={fileFormat.separator}
                  onChange={(e) => handleFormatFieldChange('separator', e.target.value)}
                />
              </div>
              <span className="help-icon" title="Character used to separate columns">?</span>
            </div>

            {/* Optionally Enclosed By */}
            <div className="flex items-center">
              <label className="w-56 text-sm text-gray-700 flex-shrink-0">
                Optionally Enclosed By
              </label>
              <div className="flex-1">
                <input
                  type="text"
                  className="form-input w-32"
                  value={fileFormat.enclosedBy}
                  onChange={(e) => handleFormatFieldChange('enclosedBy', e.target.value)}
                />
              </div>
              <span className="help-icon" title="Character used to enclose text fields">?</span>
            </div>

            {/* First Row has Column Names */}
            <div className="flex items-center">
              <label className="w-56 text-sm text-gray-700 flex-shrink-0">
                First Row has Column Names
              </label>
              <div className="flex-1 flex items-center">
                <input
                  type="checkbox"
                  id="firstRowColNames"
                  className="w-4 h-4 mr-2 accent-enterprise-blue"
                  checked={fileFormat.firstRowHasColumnNames}
                  onChange={(e) => handleFormatFieldChange('firstRowHasColumnNames', e.target.checked)}
                />
                <label htmlFor="firstRowColNames" className="text-sm text-gray-700 cursor-pointer">
                  Yes
                </label>
              </div>
              <span className="help-icon" title="Check if the first row contains column headers">?</span>
            </div>

            {/* Use Application Date Format */}
            <div className="flex items-center">
              <label className="w-56 text-sm text-gray-700 flex-shrink-0">
                Use Application Date Format
              </label>
              <div className="flex-1 flex items-center">
                <input
                  type="checkbox"
                  id="useAppDateFormat"
                  className="w-4 h-4 mr-2 accent-enterprise-blue"
                  checked={fileFormat.useApplicationDateFormat}
                  onChange={(e) => handleFormatFieldChange('useApplicationDateFormat', e.target.checked)}
                />
                <label htmlFor="useAppDateFormat" className="text-sm text-gray-700 cursor-pointer">
                  Yes
                </label>
              </div>
              <span className="help-icon" title="Use the application's default date format">?</span>
            </div>

            {/* File Character Set */}
            <div className="flex items-center">
              <label className="w-56 text-sm text-gray-700 flex-shrink-0">
                File Character Set
              </label>
              <div className="flex-1">
                <select
                  className="form-select w-40"
                  value={fileFormat.fileCharacterSet}
                  onChange={(e) => handleFormatFieldChange('fileCharacterSet', e.target.value)}
                >
                  <option value="UTF-8">UTF-8</option>
                  <option value="ISO-8859-1">ISO-8859-1</option>
                  <option value="GBK">GBK</option>
                  <option value="GB2312">GB2312</option>
                  <option value="UTF-16">UTF-16</option>
                  <option value="ASCII">ASCII</option>
                </select>
              </div>
              <span className="help-icon" title="Character encoding of the source file">?</span>
            </div>
          </div>

          {/* Globalization 板块 */}
          <div className="mt-8 pt-4 border-t border-enterprise-border">
            <h2 className="text-sm font-bold text-gray-800 mb-4">Globalization</h2>
            <div className="space-y-4">
              {/* Currency Symbol */}
              <div className="flex items-center">
                <label className="w-56 text-sm text-gray-700 flex-shrink-0">
                  Currency Symbol
                </label>
                <div className="flex-1">
                  <input
                    type="text"
                    className="form-input w-32"
                    value={globalization.currencySymbol}
                    onChange={(e) => handleGlobalFieldChange('currencySymbol', e.target.value)}
                  />
                </div>
                <span className="help-icon" title="Symbol used for currency values">?</span>
              </div>

              {/* Group Separator */}
              <div className="flex items-center">
                <label className="w-56 text-sm text-gray-700 flex-shrink-0">
                  Group Separator
                </label>
                <div className="flex-1">
                  <input
                    type="text"
                    className="form-input w-32"
                    value={globalization.groupSeparator}
                    onChange={(e) => handleGlobalFieldChange('groupSeparator', e.target.value)}
                  />
                </div>
                <span className="help-icon" title="Character used to group thousands">?</span>
              </div>

              {/* Decimal Character */}
              <div className="flex items-center">
                <label className="w-56 text-sm text-gray-700 flex-shrink-0">
                  Decimal Character
                </label>
                <div className="flex-1">
                  <input
                    type="text"
                    className="form-input w-32"
                    value={globalization.decimalCharacter}
                    onChange={(e) => handleGlobalFieldChange('decimalCharacter', e.target.value)}
                  />
                </div>
                <span className="help-icon" title="Character used as decimal point">?</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataLoadSource;
