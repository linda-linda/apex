import React, { useEffect, useRef, useState } from 'react';
import type { FieldMapping, SourceFieldOption } from '../../types';
import { SOURCE_OPTIONS, DO_NOT_LOAD_KEY } from '../../config/sourceOptions';

/* ==================== SourceColumnSelect 自定义下拉 ==================== */

interface SourceColumnSelectProps {
  options: SourceFieldOption[];
  value: string;
  /** 已被其它 Target 行占用的源字段 key（互斥，需置灰禁用） */
  disabledKeys: string[];
  onChange: (key: string) => void;
  placeholder?: string;
}

/**
 * Source Column 下拉选择器
 * - 白底列表，选项带数据类型灰色小字
 * - 当前选中项高亮（蓝色 + 对勾）
 * - 已被其它行选中的源字段置灰禁用（互斥）
 */
const SourceColumnSelect: React.FC<SourceColumnSelectProps> = ({
  options,
  value,
  disabledKeys,
  onChange,
  placeholder = 'Select a source column...',
}) => {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // 点击外部 / Escape 关闭
  useEffect(() => {
    if (!open) return;
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('keydown', handleKey);
    };
  }, [open]);

  const selected = options.find((opt) => opt.key === value);

  return (
    <div ref={containerRef} className="relative">
      {/* Trigger */}
      <button
        type="button"
        className={`w-full min-w-[260px] flex items-center justify-between gap-2 px-3 py-1.5 text-left text-[13px] border rounded bg-white transition-colors ${
          open
            ? 'border-enterprise-blue ring-2 ring-blue-100'
            : 'border-enterprise-border hover:border-gray-400'
        }`}
        onClick={() => setOpen((prev) => !prev)}
      >
        {selected ? (
          <span className="flex items-center justify-between w-full gap-2">
            <span className={`font-medium ${selected.doNotLoad ? 'text-gray-400 italic' : 'text-gray-800'}`}>
              {selected.label}
            </span>
            {!selected.doNotLoad && (
              <span className="text-[11px] text-gray-400 flex-shrink-0">{selected.type}</span>
            )}
          </span>
        ) : (
          <span className="text-gray-400">{placeholder}</span>
        )}
        <svg
          className={`w-4 h-4 text-gray-400 flex-shrink-0 transition-transform ${open ? 'rotate-180' : ''}`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {/* Panel */}
      {open && (
        <div className="absolute left-0 top-full mt-1 w-full min-w-[300px] max-h-72 overflow-auto bg-white border border-enterprise-border rounded shadow-lg z-30 py-1">
          {options.map((opt) => {
            const isDisabled =
              !opt.doNotLoad && disabledKeys.includes(opt.key) && opt.key !== value;
            const isSelected = opt.key === value;
            return (
              <button
                key={opt.key}
                type="button"
                disabled={isDisabled}
                onClick={() => {
                  onChange(opt.key);
                  setOpen(false);
                }}
                className={`w-full flex items-center justify-between gap-2 px-3 py-2 text-[13px] text-left transition-colors ${
                  isDisabled
                    ? 'text-gray-300 bg-gray-50 cursor-not-allowed'
                    : isSelected
                    ? 'bg-blue-50 text-enterprise-blue font-medium'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <span className="flex items-center gap-2 min-w-0">
                  {opt.doNotLoad ? (
                    <span className="italic text-gray-400">Do Not Load</span>
                  ) : (
                    <>
                      <span className="truncate">{opt.label}</span>
                      {opt.required && <span className="text-enterprise-error text-[11px]">*</span>}
                    </>
                  )}
                </span>
                <span className="flex items-center gap-2 flex-shrink-0">
                  {!opt.doNotLoad && (
                    <span className={`text-[11px] ${isDisabled ? 'text-gray-300' : 'text-gray-400'}`}>
                      {opt.type}
                    </span>
                  )}
                  {isSelected && (
                    <svg className="w-4 h-4 text-enterprise-blue flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                  {isDisabled && (
                    <svg className="w-3.5 h-3.5 text-gray-300 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                    </svg>
                  )}
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};

/* ==================== DataTableMapping ==================== */

interface DataTableMappingProps {
  fieldMappings: FieldMapping[];
  onMappingChange: (index: number, sourceKey: string) => void;
  onCancel: () => void;
  onPrevious: () => void;
  onNext: () => void;
}

/**
 * Step2: Business Channel Data / Table Mapping
 * Target Column（只读）→ Source Column（下拉联动选择）→ Row1/Row2 预览
 * 联动规则：
 *  1. 每个 Target 行通过下拉选择映射的源字段
 *  2. 互斥：同一源字段只能被一个 Target 行选中，其余行自动置灰
 *  3. 预览：选中源字段后，Row1/Row2 联动显示该字段样例值
 *  4. Do Not Load：不映射任何源列，预览置空
 *  5. 所有 Target 行完成映射（或 Do Not Load）后 Next 才可用
 */
const DataTableMapping: React.FC<DataTableMappingProps> = ({
  fieldMappings,
  onMappingChange,
  onCancel,
  onPrevious,
  onNext,
}) => {
  const mappedCount = fieldMappings.filter((m) => m.source !== '').length;
  const totalCount = fieldMappings.length;
  const allMapped = mappedCount === totalCount;

  /** 根据选中的源字段返回 Row1/Row2 预览值 */
  const getPreview = (mapping: FieldMapping): { row1: string; row2: string } => {
    const opt = SOURCE_OPTIONS.find((o) => o.key === mapping.source);
    if (!opt || opt.doNotLoad) return { row1: '', row2: '' };
    return { row1: opt.sampleRow1 ?? '', row2: opt.sampleRow2 ?? '' };
  };

  return (
    <div className="flex flex-col h-full">
      {/* 顶部操作栏 */}
      <div className="flex items-center justify-between px-8 py-4 border-b border-enterprise-border bg-white">
        <div className="flex items-center gap-3">
          <button className="btn btn-secondary" onClick={onCancel}>
            Cancel
          </button>
          <button className="btn btn-secondary" onClick={onPrevious}>
            Previous
          </button>
        </div>
        <button
          className="btn btn-primary"
          onClick={onNext}
          disabled={!allMapped}
          title={allMapped ? 'Proceed to data validation' : 'Map all target columns before proceeding'}
        >
          Next
        </button>
      </div>

      {/* 提示文字 */}
      <div className="px-8 py-3 bg-enterprise-bg border-b border-enterprise-border">
        <p className="text-sm text-gray-600 italic">
          Screen Displays Column Mapping for Reference, Full Row Count from Source File is
          Under "Data Validation"
        </p>
      </div>

      {/* 映射表格内容区 */}
      <div className="flex-1 overflow-auto px-8 py-6 bg-enterprise-bg">
        <div className="bg-white border border-enterprise-border rounded overflow-hidden">
          <div className="overflow-x-auto">
            <table className="enterprise-table min-w-full">
              <thead>
                <tr>
                  <th className="w-56 bg-gray-100 font-semibold text-gray-700">Target Column</th>
                  <th className="bg-gray-100 font-semibold text-gray-700">Source Column</th>
                  <th className="w-44 bg-gray-100 font-semibold text-gray-700">Row 1</th>
                  <th className="w-44 bg-gray-100 font-semibold text-gray-700">Row 2</th>
                </tr>
              </thead>
              <tbody>
                {fieldMappings.map((mapping, index) => {
                  const preview = getPreview(mapping);
                  // 互斥：收集其它行已选中的真实源字段（不含 Do Not Load）
                  const disabledKeys = fieldMappings
                    .filter((_, i) => i !== index)
                    .map((m) => m.source)
                    .filter((s) => s !== '' && s !== DO_NOT_LOAD_KEY);
                  return (
                    <tr key={mapping.target.name}>
                      <td className="align-top">
                        <span className="font-medium text-gray-800 whitespace-nowrap">
                          {mapping.target.name}
                        </span>
                        <span className="ml-1 text-[11px] text-gray-400 whitespace-nowrap">
                          - {mapping.target.type}
                        </span>
                        {mapping.target.required && (
                          <span className="ml-1 text-enterprise-error">*</span>
                        )}
                      </td>
                      <td className="align-top">
                        <SourceColumnSelect
                          options={SOURCE_OPTIONS}
                          value={mapping.source}
                          disabledKeys={disabledKeys}
                          onChange={(key) => onMappingChange(index, key)}
                        />
                      </td>
                      <td className="text-gray-600 font-mono text-[13px] whitespace-nowrap">
                        {preview.row1 || <span className="text-gray-300">—</span>}
                      </td>
                      <td className="text-gray-600 font-mono text-[13px] whitespace-nowrap">
                        {preview.row2 || <span className="text-gray-300">—</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* 映射状态与说明 */}
        <div className="mt-4 flex items-center justify-between gap-4 flex-wrap">
          <p className="text-xs text-gray-500">
            * Indicates required field. Each source column can be mapped to only one target
            column (mutually exclusive).
          </p>
          <p
            className={`text-xs font-medium ${
              allMapped ? 'text-enterprise-green' : 'text-amber-600'
            }`}
          >
            {allMapped
              ? `✓ All ${totalCount} target columns mapped`
              : `${mappedCount} of ${totalCount} target columns mapped — select a source column or "Do Not Load" for each`}
          </p>
        </div>
      </div>
    </div>
  );
};

export default DataTableMapping;
