import React, { useState } from 'react';
import StepIndicator from './StepIndicator';
import DataLoadSource from './steps/DataLoadSource';
import DataTableMapping from './steps/DataTableMapping';
import DataValidation from './steps/DataValidation';
import DataLoadResults from './steps/DataLoadResults';
import type {
  FileInfo,
  FileFormatConfig,
  GlobalizationConfig,
  FieldMapping,
  ValidationRow,
  LoadResults,
  StepDefinition,
} from '../types';

/** 步骤定义 */
const STEPS: StepDefinition[] = [
  { id: 1, label: 'Business Channel - Data Load Source' },
  { id: 2, label: 'Business Channel - Data / Table Mapping' },
  { id: 3, label: 'Business Channel - Data Validation' },
  { id: 4, label: 'Business Channel - Data Load Results' },
];

/** 默认文件格式配置 */
const defaultFileFormat: FileFormatConfig = {
  separator: ',',
  enclosedBy: '"',
  firstRowHasColumnNames: true,
  useApplicationDateFormat: true,
  fileCharacterSet: 'UTF-8',
};

/** 默认全球化配置 */
const defaultGlobalization: GlobalizationConfig = {
  currencySymbol: '$',
  groupSeparator: ',',
  decimalCharacter: '.',
};

/** 默认字段映射（初始均未映射，需在 Step2 逐个通过下拉完成，source 为空字符串表示未映射） */
const defaultFieldMappings: FieldMapping[] = [
  {
    target: { name: 'ID_BUSINESS_CHANNEL', type: 'number', required: true },
    source: '',
  },
  {
    target: { name: 'PL_REPORTING_LINE', type: 'varchar2(100)' },
    source: '',
  },
  {
    target: { name: 'COUNTERPARTY', type: 'varchar2(100)' },
    source: '',
  },
  {
    target: { name: 'BUSINESS_CHANNEL', type: 'varchar2(100)' },
    source: '',
  },
  {
    target: { name: 'DERIVED_CHANNEL', type: 'varchar2(100)' },
    source: '',
  },
];

/** 默认校验行数据（mock） */
const defaultValidationRows: ValidationRow[] = [
  {
    sequence: 1,
    action: 'INSERT',
    idBusinessChannel: '544',
    plReportingLine: 'Commission income',
    counterparty: 'ICO',
    businessChannel: 'MP',
    derivedChannel: 'MEM',
    hasError: false,
  },
  {
    sequence: 2,
    action: 'INSERT',
    idBusinessChannel: '545',
    plReportingLine: 'Commission income',
    counterparty: 'ICO',
    businessChannel: 'XA',
    derivedChannel: 'DSA',
    hasError: false,
  },
];

/** 默认加载结果统计 */
const defaultLoadResults: LoadResults = {
  insertedRows: 2,
  updatedRows: 0,
  failedRows: 0,
  toBeReviewedRows: 0,
};

/**
 * BusinessChannelDataLoadWizard 主组件
 * 管理4步向导的全局状态与页面流转
 */
const BusinessChannelDataLoadWizard: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [fileFormat, setFileFormat] = useState<FileFormatConfig>(defaultFileFormat);
  const [globalization, setGlobalization] = useState<GlobalizationConfig>(defaultGlobalization);
  const [fieldMappings, setFieldMappings] = useState<FieldMapping[]>(defaultFieldMappings);
  const [validationRows] = useState<ValidationRow[]>(defaultValidationRows);
  const [loadResults] = useState<LoadResults>(defaultLoadResults);

  /** 重置全部状态，回到 Step1 */
  const handleReset = () => {
    setCurrentStep(1);
    setFileInfo(null);
    setFileFormat(defaultFileFormat);
    setGlobalization(defaultGlobalization);
    setFieldMappings(defaultFieldMappings.map((m) => ({ ...m })));
  };

  /** Cancel：任意步骤重置回 Step1 */
  const handleCancel = () => {
    handleReset();
  };

  /** Step1 Next → Step2 */
  const handleStep1Next = () => {
    setCurrentStep(2);
  };

  /** Step2 Previous → Step1 */
  const handleStep2Previous = () => {
    setCurrentStep(1);
  };

  /** Step2 Next → Step3 */
  const handleStep2Next = () => {
    setCurrentStep(3);
  };

  /** Step2 字段映射联动更新（互斥由 DataTableMapping 下拉控制） */
  const handleMappingChange = (index: number, sourceKey: string) => {
    setFieldMappings((prev) =>
      prev.map((m, i) => (i === index ? { ...m, source: sourceKey } : m))
    );
  };

  /** Step3 Previous → Step2 */
  const handleStep3Previous = () => {
    setCurrentStep(2);
  };

  /** Step3 Load Data → Step4 */
  const handleLoadData = () => {
    setCurrentStep(4);
  };

  /** Step4 Finish → 重置回 Step1 */
  const handleFinish = () => {
    handleReset();
  };

  /** 渲染当前步骤内容 */
  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <DataLoadSource
            fileInfo={fileInfo}
            fileFormat={fileFormat}
            globalization={globalization}
            onFileChange={setFileInfo}
            onFileFormatChange={setFileFormat}
            onGlobalizationChange={setGlobalization}
            onCancel={handleCancel}
            onNext={handleStep1Next}
          />
        );
      case 2:
        return (
          <DataTableMapping
            fieldMappings={fieldMappings}
            onMappingChange={handleMappingChange}
            onCancel={handleCancel}
            onPrevious={handleStep2Previous}
            onNext={handleStep2Next}
          />
        );
      case 3:
        return (
          <DataValidation
            validationRows={validationRows}
            onCancel={handleCancel}
            onPrevious={handleStep3Previous}
            onLoadData={handleLoadData}
          />
        );
      case 4:
        return (
          <DataLoadResults
            loadResults={loadResults}
            onCancel={handleCancel}
            onFinish={handleFinish}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col h-screen bg-white">
      {/* 公共步骤指示器 */}
      <StepIndicator steps={STEPS} currentStep={currentStep} />

      {/* 当前步骤内容 */}
      <div className="flex-1 overflow-hidden">{renderStepContent()}</div>
    </div>
  );
};

export default BusinessChannelDataLoadWizard;
