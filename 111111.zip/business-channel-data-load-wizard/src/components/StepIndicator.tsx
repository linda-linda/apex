import React from 'react';
import type { StepDefinition } from '../types';

interface StepIndicatorProps {
  steps: StepDefinition[];
  currentStep: number;
}

/**
 * 公共步骤指示器
 * 已完成=绿色对勾；当前步骤=蓝色圆点；未完成=灰色圆点
 */
const StepIndicator: React.FC<StepIndicatorProps> = ({ steps, currentStep }) => {
  return (
    <div className="w-full py-6 px-8 bg-white border-b border-enterprise-border">
      <div className="flex items-center justify-between max-w-5xl mx-auto">
        {steps.map((step, index) => {
          const isCompleted = step.id < currentStep;
          const isCurrent = step.id === currentStep;
          const isLast = index === steps.length - 1;

          return (
            <React.Fragment key={step.id}>
              <div className="flex flex-col items-center flex-shrink-0">
                {/* 圆点 / 对勾 */}
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-semibold transition-colors duration-200 ${
                    isCompleted
                      ? 'bg-enterprise-green'
                      : isCurrent
                      ? 'bg-enterprise-blue'
                      : 'bg-enterprise-gray'
                  }`}
                >
                  {isCompleted ? (
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={3}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                  ) : (
                    step.id
                  )}
                </div>
                {/* 步骤标签 */}
                <span
                  className={`mt-2 text-xs text-center max-w-[180px] leading-tight ${
                    isCurrent
                      ? 'text-enterprise-blue font-semibold'
                      : isCompleted
                      ? 'text-enterprise-green font-medium'
                      : 'text-enterprise-gray'
                  }`}
                >
                  {step.label}
                </span>
              </div>
              {/* 连接线 */}
              {!isLast && (
                <div
                  className={`flex-1 h-0.5 mx-2 mb-6 transition-colors duration-200 ${
                    isCompleted ? 'bg-enterprise-green' : 'bg-enterprise-gray'
                  }`}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};

export default StepIndicator;
