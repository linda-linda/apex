import type { SourceFieldOption } from '../types';

/** "Do Not Load" 特殊选项 key */
export const DO_NOT_LOAD_KEY = 'DO_NOT_LOAD';

/**
 * Step2 Source Column 下拉候选（写死的 8 项，含 Do Not Load）
 * 每个选项附带数据类型与 Row1/Row2 样例值，用于预览联动
 */
export const SOURCE_OPTIONS: SourceFieldOption[] = [
  { key: DO_NOT_LOAD_KEY, label: 'Do Not Load', type: '', doNotLoad: true },
  {
    key: 'BUSINESS_CHANNEL',
    label: 'BUSINESS_CHANNEL',
    type: 'varchar2(100)',
    sampleRow1: 'MP',
    sampleRow2: 'XA',
  },
  {
    key: 'COUNTERPARTY',
    label: 'COUNTERPARTY',
    type: 'varchar2(100)',
    sampleRow1: 'ICO',
    sampleRow2: 'ICO',
  },
  {
    key: 'DERIVED_CHANNEL',
    label: 'DERIVED_CHANNEL',
    type: 'varchar2(100)',
    sampleRow1: 'MEM',
    sampleRow2: 'DSA',
  },
  {
    key: 'ID_BUSINESS_CHANNEL',
    label: 'ID_BUSINESS_CHANNEL',
    type: 'number',
    required: true,
    sampleRow1: '544',
    sampleRow2: '545',
  },
  {
    key: 'PL_REPORTING_LINE',
    label: 'PL_REPORTING_LINE',
    type: 'varchar2(100)',
    sampleRow1: 'Commission income',
    sampleRow2: 'Commission income',
  },
  {
    key: 'SOURCE_FROM',
    label: 'SOURCE_FROM',
    type: 'varchar2(50)',
    sampleRow1: 'CSV_IMPORT',
    sampleRow2: 'CSV_IMPORT',
  },
  {
    key: 'VERSION_ID',
    label: 'VERSION_ID',
    type: 'number',
    sampleRow1: '1',
    sampleRow2: '1',
  },
];

/** 按 key 查找源字段选项 */
export const getSourceOption = (key: string): SourceFieldOption | undefined =>
  SOURCE_OPTIONS.find((opt) => opt.key === key);
